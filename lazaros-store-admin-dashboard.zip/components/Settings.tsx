
import React, { useState } from 'react';
import { saveConfig } from '../services/githubDB';

const Settings: React.FC = () => {
  const [token, setToken] = useState(localStorage.getItem('gh_token') || '');
  const [owner, setOwner] = useState(localStorage.getItem('gh_owner') || '');
  const [repo, setRepo] = useState(localStorage.getItem('gh_repo') || '');

  const handleSave = () => {
    saveConfig(token, owner, repo);
    alert('تم حفظ الإعدادات وإعادة تشغيل النظام بنجاح');
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-sm border p-8">
      <h3 className="text-2xl font-bold text-slate-800 mb-2">إعدادات قاعدة البيانات (GitHub)</h3>
      <p className="text-slate-500 mb-8">اربط لوحة التحكم بملف البيانات الخاص بك على مستودع GitHub</p>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">GitHub Personal Access Token</label>
          <input 
            type="password" 
            value={token}
            onChange={e => setToken(e.target.value)}
            placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none font-mono"
          />
          <p className="text-xs text-slate-400 mt-2">تحتاج للتوكن من أجل حفظ التغييرات مباشرة في الكود</p>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">GitHub Owner (User)</label>
            <input 
              type="text" 
              value={owner}
              onChange={e => setOwner(e.target.value)}
              placeholder="Username"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">GitHub Repo Name</label>
            <input 
              type="text" 
              value={repo}
              onChange={e => setRepo(e.target.value)}
              placeholder="lazaros-store"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none"
            />
          </div>
        </div>

        <div className="pt-6 border-t">
          <button 
            onClick={handleSave}
            className="w-full bg-indigo-900 text-white font-bold py-4 rounded-xl hover:bg-indigo-950 shadow-xl shadow-indigo-900/20 transition-all active:scale-[0.98]"
          >
            حفظ إعدادات الربط
          </button>
        </div>
      </div>

      <div className="mt-12 p-6 bg-amber-50 rounded-2xl border border-amber-100">
        <h4 className="font-bold text-amber-800 flex items-center gap-2 mb-2">
          <i className="fas fa-exclamation-triangle"></i> ملاحظة هامة
        </h4>
        <p className="text-sm text-amber-700">
          يتم تخزين البيانات في ملف <code className="bg-amber-100 px-1 rounded">data.json</code> في المسار الرئيسي للمستودع. تأكد من أن التوكن لديه صلاحية الوصول لـ <code className="bg-amber-100 px-1 rounded">repo</code>.
        </p>
      </div>
    </div>
  );
};

export default Settings;
