
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeSection, onSectionChange, onLogout }) => {
  const menuItems = [
    { id: 'overview', icon: 'fa-chart-pie', label: 'نظرة عامة' },
    { id: 'instagram', icon: 'fa-instagram', label: 'إنستجرام' },
    { id: 'facebook', icon: 'fa-facebook', label: 'فيسبوك' },
    { id: 'tiktok', icon: 'fa-tiktok', label: 'تيك توك' },
    { id: 'chat', icon: 'fa-comment-dots', label: 'اشتراكات تشات' },
    { id: 'gemini', icon: 'fa-robot', label: 'جيمناي' },
    { id: 'settings', icon: 'fa-cog', label: 'الإعدادات' },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-indigo-900 text-white flex flex-col shadow-xl">
        <div className="p-6 border-b border-indigo-800">
          <h1 className="text-xl font-bold tracking-wider text-sky-400">LAZAROS ADMIN</h1>
          <p className="text-xs text-indigo-300 mt-1">لوحة تحكم المتجر</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeSection === item.id 
                ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/30' 
                : 'hover:bg-indigo-800 text-indigo-100'
              }`}
            >
              <i className={`fas ${item.icon} w-5`}></i>
              <span className="font-semibold">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-indigo-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-300 hover:bg-red-500/10 transition-colors"
          >
            <i className="fas fa-sign-out-alt w-5"></i>
            <span className="font-semibold">تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b flex items-center justify-between px-8 shadow-sm">
          <h2 className="text-lg font-bold text-slate-800">
            {menuItems.find(m => m.id === activeSection)?.label || 'لوحة التحكم'}
          </h2>
          <div className="flex items-center gap-4">
            <div className="bg-sky-50 text-sky-700 px-3 py-1 rounded-full text-xs font-bold border border-sky-100">
              متصل بقاعدة البيانات
            </div>
            <img src="https://picsum.photos/40/40" className="w-10 h-10 rounded-full border-2 border-sky-200" alt="Admin" />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
