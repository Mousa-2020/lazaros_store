
import React, { useState } from 'react';
import { StoreData, ServiceData, SectionType } from '../types';

interface Props {
  section: SectionType;
  data: StoreData;
  onSave: (newData: StoreData) => void;
}

const ServiceManager: React.FC<Props> = ({ section, data, onSave }) => {
  const currentSectionData = data[section] as Record<string, ServiceData>;
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempService, setTempService] = useState<Partial<ServiceData>>({});

  const handleEdit = (id: string) => {
    setEditingId(id);
    setTempService(currentSectionData[id]);
  };

  const handleAddNew = () => {
    const id = `new_${Date.now()}`;
    setEditingId(id);
    setTempService({
      title: 'خدمة جديدة',
      description: 'وصف الخدمة',
      type: 'direct',
      packages: []
    });
  };

  const saveService = () => {
    if (!editingId) return;
    const newData = { ...data };
    (newData[section] as any)[editingId] = tempService;
    onSave(newData);
    setEditingId(null);
  };

  const deleteService = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه الخدمة؟')) {
      const newData = { ...data };
      delete (newData[section] as any)[id];
      onSave(newData);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-slate-800 capitalize">إدارة {section}</h3>
        <button 
          onClick={handleAddNew}
          className="bg-sky-500 hover:bg-sky-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-sky-500/20"
        >
          <i className="fas fa-plus"></i> إضافة خدمة جديدة
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(currentSectionData).map(([id, service]) => (
          <div key={id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:border-sky-200 transition-colors group">
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-sky-100 group-hover:text-sky-500 transition-colors">
                <i className="fas fa-layer-group text-xl"></i>
              </div>
              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => handleEdit(id)} className="p-2 text-slate-400 hover:text-sky-500"><i className="fas fa-edit"></i></button>
                <button onClick={() => deleteService(id)} className="p-2 text-slate-400 hover:text-red-500"><i className="fas fa-trash"></i></button>
              </div>
            </div>
            <h4 className="text-lg font-bold text-slate-800">{service.title}</h4>
            <p className="text-sm text-slate-500 mt-2 line-clamp-2">{service.description}</p>
            <div className="mt-4 pt-4 border-t flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
              <span>{service.type}</span>
              <span className="text-sky-500">{Array.isArray(service.packages) ? service.packages.length : 'مقسمة'} باقات</span>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editingId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl p-8 relative">
            <h3 className="text-2xl font-bold text-slate-800 mb-6">تعديل الخدمة</h3>
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">اسم الخدمة</label>
                <input 
                  type="text" 
                  value={tempService.title} 
                  onChange={e => setTempService({...tempService, title: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">الوصف</label>
                <textarea 
                  value={tempService.description} 
                  onChange={e => setTempService({...tempService, description: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none h-24"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">النوع</label>
                  <select 
                    value={tempService.type}
                    onChange={e => setTempService({...tempService, type: e.target.value as any})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none"
                  >
                    <option value="direct">مباشر (باقات فقط)</option>
                    <option value="category">فئات (مثل جنسيات)</option>
                    <option value="contact">تواصل فقط</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex gap-4 mt-10">
              <button 
                onClick={saveService}
                className="flex-1 bg-sky-500 text-white font-bold py-3 rounded-xl hover:bg-sky-600 shadow-lg shadow-sky-500/20"
              >
                حفظ التغييرات
              </button>
              <button 
                onClick={() => setEditingId(null)}
                className="px-8 bg-slate-100 text-slate-600 font-bold py-3 rounded-xl hover:bg-slate-200"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceManager;
