
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { StoreData } from '../types';

interface Props {
  data: StoreData;
}

const DashboardHome: React.FC<Props> = ({ data }) => {
  const stats = [
    { label: 'إنستجرام', count: Object.keys(data.instagram || {}).length, color: '#405de6', icon: 'fa-instagram' },
    { label: 'فيسبوك', count: Object.keys(data.facebook || {}).length, color: '#1877F2', icon: 'fa-facebook' },
    { label: 'تيك توك', count: Object.keys(data.tiktok || {}).length, color: '#000000', icon: 'fa-tiktok' },
    { label: 'اشتراكات', count: (Object.keys(data.chat || {}).length + Object.keys(data.gemini || {}).length), color: '#8e24aa', icon: 'fa-robot' },
  ];

  const chartData = stats.map(s => ({ name: s.label, value: s.count }));

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between group hover:shadow-md transition-shadow">
            <div>
              <p className="text-slate-500 text-sm font-semibold">{stat.label}</p>
              <h3 className="text-3xl font-bold text-slate-800 mt-1">{stat.count}</h3>
              <p className="text-xs text-green-500 mt-1 font-bold">نشط</p>
            </div>
            <div 
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl text-white shadow-lg transition-transform group-hover:scale-110"
              style={{ backgroundColor: stat.color }}
            >
              <i className={`fab ${stat.icon}`}></i>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold text-slate-800 mb-6">توزيع الخدمات المتاحة</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={50}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={stats[index].color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold text-slate-800 mb-6">آخر العمليات</h3>
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-sky-100 flex items-center justify-center text-sky-600">
                  <i className="fas fa-plus"></i>
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800">تحديث باقة إنستجرام</p>
                  <p className="text-xs text-slate-500">منذ ٢ ساعة بواسطة الأدمن</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 bg-slate-50 text-slate-600 rounded-xl font-bold hover:bg-slate-100 transition-colors">
            عرض كافة السجلات
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
