
import React, { useState } from 'react';

interface Props {
  onLogin: (password: string) => void;
}

const Login: React.FC<Props> = ({ onLogin }) => {
  const [pass, setPass] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(pass);
  };

  return (
    <div className="min-h-screen bg-indigo-950 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-100 rounded-full -mr-16 -mt-16 blur-3xl opacity-50"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-100 rounded-full -ml-16 -mb-16 blur-3xl opacity-50"></div>
        
        <div className="relative text-center mb-10">
          <div className="w-20 h-20 bg-indigo-900 rounded-3xl mx-auto flex items-center justify-center text-white text-3xl shadow-xl shadow-indigo-900/30 mb-6">
            <i className="fas fa-lock"></i>
          </div>
          <h2 className="text-3xl font-bold text-slate-800">لوحة تحكم الأدمن</h2>
          <p className="text-slate-500 mt-2">يرجى إدخال كلمة المرور للمتابعة</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 relative">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 mr-1">كلمة المرور</label>
            <input 
              type="password"
              value={pass}
              onChange={e => setPass(e.target.value)}
              className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10 outline-none transition-all"
              placeholder="••••••••"
              required
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-indigo-900 hover:bg-indigo-950 text-white font-bold py-4 rounded-2xl shadow-xl shadow-indigo-900/20 transition-all active:scale-[0.98]"
          >
            تسجيل الدخول
          </button>
        </form>
        
        <p className="text-center text-slate-400 text-xs mt-10 uppercase tracking-widest font-bold">
          © 2025 LAZAROS STORE
        </p>
      </div>
    </div>
  );
};

export default Login;
