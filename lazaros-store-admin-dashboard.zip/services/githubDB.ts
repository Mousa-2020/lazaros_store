
/**
 * هذا الملف يحاكي التعامل مع GitHub كقاعدة بيانات.
 * نستخدم ملف JSON مخزن في المستودع (Repository).
 */

const GITHUB_CONFIG = {
  token: localStorage.getItem('gh_token') || '',
  owner: localStorage.getItem('gh_owner') || '',
  repo: localStorage.getItem('gh_repo') || '',
  path: 'data.json'
};

export const saveConfig = (token: string, owner: string, repo: string) => {
  localStorage.setItem('gh_token', token);
  localStorage.setItem('gh_owner', owner);
  localStorage.setItem('gh_repo', repo);
  window.location.reload();
};

export const isConfigured = () => {
  return !!(localStorage.getItem('gh_token') && localStorage.getItem('gh_owner') && localStorage.getItem('gh_repo'));
};

export const fetchFromGitHub = async (): Promise<any> => {
  if (!isConfigured()) return null;

  try {
    const url = `https://api.github.com/repos/${localStorage.getItem('gh_owner')}/${localStorage.getItem('gh_repo')}/contents/${GITHUB_CONFIG.path}`;
    const response = await fetch(url, {
      headers: {
        Authorization: `token ${localStorage.getItem('gh_token')}`,
        Accept: 'application/vnd.github.v3+json'
      }
    });

    if (!response.ok) throw new Error('فشل جلب البيانات من GitHub');
    
    const data = await response.json();
    const content = atob(data.content);
    return JSON.parse(decodeURIComponent(escape(content)));
  } catch (error) {
    console.error(error);
    return null;
  }
};

export const saveToGitHub = async (data: any): Promise<boolean> => {
  if (!isConfigured()) return false;

  try {
    const url = `https://api.github.com/repos/${localStorage.getItem('gh_owner')}/${localStorage.getItem('gh_repo')}/contents/${GITHUB_CONFIG.path}`;
    
    // جلب الـ SHA للملف الحالي لتحديثه
    const getFile = await fetch(url, {
      headers: { Authorization: `token ${localStorage.getItem('gh_token')}` }
    });
    let sha = '';
    if (getFile.ok) {
      const fileData = await getFile.json();
      sha = fileData.sha;
    }

    const content = btoa(unescape(encodeURIComponent(JSON.stringify(data, null, 2))));
    
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        Authorization: `token ${localStorage.getItem('gh_token')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: 'Update store data via Admin Dashboard',
        content,
        sha: sha || undefined
      })
    });

    return response.ok;
  } catch (error) {
    console.error(error);
    return false;
  }
};
